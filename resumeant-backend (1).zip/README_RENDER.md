# ResumeAnt Backend (Render Deployment Guide)

## 1) Create a Web Service
- Go to https://render.com
- New + → Web Service → Connect this folder (via GitHub or upload .zip)

## 2) Settings
**Environment:** Python

**Build Command:**
```
pip install -r requirements.txt
```

**Start Command:**
```
uvicorn app:app --host 0.0.0.0 --port 10000
```

## 3) Environment Variables
```
PROVIDER=openai
OPENAI_API_KEY=sk-...yourkey...
SESSION_SECRET=some_long_random_string
FREE_LIMIT=1
PRICE_KOBO=250000
```

## 4) Test
After deploy, you'll get a URL like:
```
https://resumeant-backend.onrender.com
```
Verify health:
```
GET https://YOUR_URL/health
```
Expect: `{"ok": true, "provider": "openai"}`
