import os
import requests

BASE_PROMPT = (
    "You are an expert resume writer and ATS optimizer. "
    "Rewrite the user's resume to be concise, results-oriented, and ATS-friendly. "
    "Use strong action verbs, quantify impact with metrics, and ensure consistent formatting. "
    "Return clean Markdown with sections: SUMMARY, SKILLS, EXPERIENCE (bullets with STAR), EDUCATION. "
)

TAILOR_PROMPT = (
    "Tailor the resume to the target job description below. "
    "Preserve truthful content; do not invent. Extract keywords & align phrasing."
)

def build_prompt(resume_text: str, job_desc: str | None = None, tone: str = "professional") -> str:
    parts = [BASE_PROMPT, f"Desired tone: {tone}.", "User resume:", resume_text]
    if job_desc:
        parts += ["\n# Target Job Description:", job_desc, TAILOR_PROMPT]
    return "\n\n".join(parts)


def call_openai(api_key: str, prompt: str) -> str:
    # Chat Completions-compatible endpoint
    url = "https://api.openai.com/v1/chat/completions"
    headers = {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}
    payload = {
        "model": "gpt-4o-mini",
        "messages": [
            {"role": "system", "content": "You produce only the improved resume in Markdown."},
            {"role": "user", "content": prompt},
        ],
        "temperature": 0.4,
    }
    r = requests.post(url, headers=headers, json=payload, timeout=60)
    r.raise_for_status()
    return r.json()["choices"][0]["message"]["content"].strip()


def call_ollama(model: str, prompt: str) -> str:
    # Assumes Ollama running locally
    url = "http://localhost:11434/api/generate"
    payload = {"model": model, "prompt": prompt, "stream": False}
    r = requests.post(url, json=payload, timeout=120)
    r.raise_for_status()
    return r.json()["response"].strip()


def enhance(resume_text: str, job_desc: str | None = None, tone: str = "professional") -> str:
    provider = os.getenv("PROVIDER", "openai")
    prompt = build_prompt(resume_text, job_desc, tone)
    if provider == "ollama":
        model = os.getenv("OLLAMA_MODEL", "llama3.1:8b")
        return call_ollama(model, prompt)
    else:
        api_key = os.getenv("OPENAI_API_KEY", "")
        if not api_key:
            raise RuntimeError("OPENAI_API_KEY missing. Set it or switch PROVIDER=ollama")
        return call_openai(api_key, prompt)


def score(resume_text: str) -> dict:
    # Lightweight heuristic score (0–100) + reasons
    score = 60
    reasons = []
    lt = resume_text.lower()
    if len(resume_text) > 800:
        score += 5
    if any(k in lt for k in ["achieved","reduced","increased","%","$","kpi","roi"]):
        score += 10; reasons.append("Has quantified impact")
    if "education" in lt:
        score += 5
    if "skills" in lt:
        score += 5
    if any(h in lt for h in ["experience","work history","employment"]):
        score += 5
    score = max(0, min(100, score))
    return {"score": score, "reasons": reasons}


def build_cover_letter_prompt(resume_text: str, job_desc: str, tone: str = "professional") -> str:
    return (
        "You are an expert career writer. Write a single-page cover letter aligned to the job description. "
        "Strictly base content on the candidate's resume; don't fabricate. Tone: " + tone + ".\n\n"
        "# Candidate Resume\n" + resume_text + "\n\n# Job Description\n" + job_desc + "\n\n"
        "Return plain text with paragraphs (no salutations if company name unknown)."
    )


def cover_letter(resume_text: str, job_desc: str, tone: str = "professional") -> str:
    provider = os.getenv("PROVIDER", "openai")
    prompt = build_cover_letter_prompt(resume_text, job_desc, tone)
    if provider == "ollama":
        model = os.getenv("OLLAMA_MODEL", "llama3.1:8b")
        return call_ollama(model, prompt)
    else:
        api_key = os.getenv("OPENAI_API_KEY", "")
        if not api_key:
            raise RuntimeError("OPENAI_API_KEY missing")
        return call_openai(api_key, prompt)


def build_linkedin_prompt(resume_text: str, tone: str = "professional") -> str:
    return (
        "Create a 260–300 character LinkedIn 'About' summary highlighting unique value, metrics, and keywords. "
        "Tone: " + tone + ". Use first person, no emojis.\n\n"
        "# Candidate Resume\n" + resume_text
    )


def linkedin_summary(resume_text: str, tone: str = "professional") -> str:
    provider = os.getenv("PROVIDER", "openai")
    prompt = build_linkedin_prompt(resume_text, tone)
    if provider == "ollama":
        model = os.getenv("OLLAMA_MODEL", "llama3.1:8b")
        return call_ollama(model, prompt)
    else:
        api_key = os.getenv("OPENAI_API_KEY", "")
        if not api_key:
            raise RuntimeError("OPENAI_API_KEY missing")
        return call_openai(api_key, prompt)
